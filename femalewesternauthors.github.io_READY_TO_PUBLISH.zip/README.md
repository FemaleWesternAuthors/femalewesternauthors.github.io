# Female Western Authors — Recognition & Reviews

Official website source for **Female Western Authors — Recognition & Reviews**.

Live site target: https://femalewesternauthors.github.io

## Publishing
This repository is designed as a GitHub Pages user/organization site.
The repository name must remain:

`femalewesternauthors.github.io`

The homepage entry file is `index.html`.
